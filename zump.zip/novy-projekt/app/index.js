var http = require("http");

var fs = require('fs');

function onRequest(request, response) {

}


http.createServer(function (request, response) {
   response.writeHead(200, {'Content-Type': 'text/html'});
    fs.readFile('./form.html', null, function(error, data) {
        if (error) {
            response.writeHead(404);
            response.write('File not found!');
        } else {
            response.write(data);
        }
        response.end();
    });
}).listen(3000);

// Console will print the message
console.log('Server running at http://127.0.0.1:3000/');