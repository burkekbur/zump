module.exports = function(grunt) {

  grunt.initConfig({
    //pkg: grunt.file.readJSON('package.json'),
    // pug task
    pug: {
      compile: {
        options: {
          data: {
            debug: true
          },
          pretty: true
        },
        files: [{
          expand: true,
          cwd: '../web/',
          src: ['**/*.pug'],
          dest: '../min/',
          ext: '.html'
        }]
      }
    },
    sass: {
      dist: {
        options: {
          style: 'inline'
        },
        files: [{
          expand: true,
          cwd: '../web/style/',
          src: ['**/*.sass'],
          dest: '../min/style/',
          ext: '.css'
        }]
      }
    },
    htmlmin: {
      dist: {
        options: {
          removeComments: true,
          collapseWhitespace: true
        },
        files: [{
          expand: true,
          cwd: '../web/',
          src: ['**/*.html'],
          dest: '../min/',
        }]
      }
    },
    cssmin: {
      options: {
        shorthandCompacting: false,
        roundingPrecision: -1
      },
      target: {
        files: {
          '../min/style/style.css': ['../web/style/*.css']
        }
      }
    },
    uglify: {
      options: {
        mangle: false
      },
      target: {
        files: {
          '../min/js/scripts.js': ['../web/js/*.js']
        }
      }
    },
    watch: {
      options: {
        // Start a live reload server on the default port 35729
        livereload: true,

      },
      pug: {
        files: ['../web/*.pug'],
        tasks: ['pug'],
      },
      sass: {
        files: ['../web/style/*.sass'],
        tasks: ['sass'],
      },
      htmls: {
        files: ['../web/*.html'],
        tasks: ['htmlmin'],
      },
      styles: {
        files: ['../web/style/*.css'],
        tasks: ['cssmin'],
      },
      scripts: {
        files: ['../web/js/*.js'],
        tasks: ['uglify'],
      },
    },
    connect: {
      server: {
        options: {
          port: 9000,
          base: '../',
          hostname: '0.0.0.0',
          protocol: 'http',
          livereload: true,
          // open: true,
          open: 'http://localhost:9000/min/index.html',
        }
      }
    },

  });

  grunt.loadNpmTasks('grunt-contrib-pug');
  grunt.loadNpmTasks('grunt-sass');
  grunt.loadNpmTasks('grunt-contrib-htmlmin');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-connect');
  grunt.loadNpmTasks('grunt-contrib-watch');
  // Default task(s).
  grunt.registerTask('default', ['pug','sass','htmlmin', 'cssmin', 'uglify', 'connect', 'watch']);

};