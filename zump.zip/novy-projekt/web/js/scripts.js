/*Vue app*/

new Vue({
 el: '#vueapp',
 data: {
 	input: '',
 },

 methods: {
 dalsi: function() {
 this.soucasneCislo += 1;
 },
 resetovat: function(){
 this.soucasneCislo = 0;
 }

 }
});